package v1beta1

// MaxComposeVersion is the most recent version of compose file Schema supported in v1beta1
const MaxComposeVersion = "3.5"
