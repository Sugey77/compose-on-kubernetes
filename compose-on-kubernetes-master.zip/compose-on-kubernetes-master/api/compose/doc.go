// +k8s:deepcopy-gen=package,register
// +groupName=compose.docker.com

// Package compose is the internal version of the API.
package compose
