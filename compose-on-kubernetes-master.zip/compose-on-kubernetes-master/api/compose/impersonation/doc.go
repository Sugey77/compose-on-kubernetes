// Package impersonation holds data structures for enabling user impersonation within Conpose for Kubernetes
// +k8s:openapi-gen=true
package impersonation
