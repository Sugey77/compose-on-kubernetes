// Api versions allow the api contract for a resource to be changed while keeping
// backward compatibility by support multiple concurrent versions
// of the same resource

// Package v1beta2 is the second version of the stack, containing a structured spec
// +k8s:openapi-gen=true
package v1beta2
