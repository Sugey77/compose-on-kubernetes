package v1alpha3

// StackListerExpansion allows custom methods to be added to
// StackLister.
type StackListerExpansion interface{}

// StackNamespaceListerExpansion allows custom methods to be added to
// StackNamespaceLister.
type StackNamespaceListerExpansion interface{}
