package v1beta2

// StackListerExpansion allows custom methods to be added to
// StackLister.
type StackListerExpansion interface{}

// StackNamespaceListerExpansion allows custom methods to be added to
// StackNamespaceLister.
type StackNamespaceListerExpansion interface{}
